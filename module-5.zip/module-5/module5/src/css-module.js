import React from 'react';  
import ReactDOM from 'react-dom';  
import styles from './mystyle.module.css';
  
class AppCssModules extends React.Component {  
  render() {  
    return (  
      <div>  
      <h1 className={styles.mystyle}>Hello CSS modules</h1>  
      <p className={styles.parastyle}>It provides STYLES too..!.</p>  
      </div>  
    );  
  }  
}  
export default AppCssModules;  