import React from 'react';  
import ReactDOM from 'react-dom';  
  
class AppStyleObject extends React.Component {  
  render() {  
    const mystyle = {  
      color: "Green",  
      backgroundColor: "lightBlue",  
      padding: "10px",  
      fontFamily: "Arial"  
    };  
    return (  
      <div>  
      <h1 style={mystyle}>Hello Style Object</h1>  
      <p>Here,I am.</p>  
      </div>  
    );  
  }  
}  
export default AppStyleObject;  