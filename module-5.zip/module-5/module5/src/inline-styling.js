import React from 'react';  
import ReactDOM from 'react-dom';  
  
class AppInline extends React.Component {  
  render() {  
    return (  
      <div>  
      <h1 style={{color: "Green"}}>Hello React!</h1>  
      <p style={{background: "Green",color: "lightblue",fontSize:"34px"}}>This is Inline Style...</p>  
      </div>  
    );  
  }  
}  
export default AppInline;  