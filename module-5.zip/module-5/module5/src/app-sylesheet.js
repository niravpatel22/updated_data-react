import React from 'react';  
import ReactDOM from 'react-dom';  
import './App.css';  
  
class AppStyleSheet extends React.Component {  
  render() {  
    return (  
      <div>  
      <h1>Hello AppStyleSheet</h1>  
      <p>Here, I am....</p>  
      </div>  
    );  
  }  
}  
export default AppStyleSheet;  