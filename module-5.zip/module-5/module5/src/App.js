import AppStyleSheet from "./app-sylesheet";
import AppCssModules from "./css-module";
import AppInline from "./inline-styling";
import AppStyleObject from "./style-object";
import Component from "./styled-component";



function App() {
  return (
   <>

    <AppInline/>
    <AppStyleObject/>
    <AppStyleSheet/>
    <AppCssModules/>
    <Component/>
   
   </>
  );
}

export default App;
