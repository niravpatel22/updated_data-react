import React from "react";

// Class MyClass extends React.Component {
//     constructor(props) {
//         super(props);
//         this.state = { attribute : "value" };
//     }
// }

// The state should never be updated explicitly. React uses an observable object as the state that observes what changes are made to the state and helps the component behave accordingly. For example, if we update the state of any component like the following the webpage will not re-render itself because React State will not be able to detect the changes made.

// this.state.attribute = "new-value";

// Thus, React provides its own method setState(). setState() method takes a single parameter and expects an object which should contain the set of values to be updated. Once the update is done the method implicitly calls the render() method to repaint the page. Hence, the correct method of updating the value of a state will be similar to the code below. 
// this.setState({attribute: "new-value"});

// Now due to asynchronous processing, this.state.count may produce an undesirable result. A more appropriate approach would be to use the following.
// In the below code, we are using the ES6 thick arrow function format to take the previous state and props of the component as parameters and are updating the counter. The same can be written using the default functional way as follows.  
// this.setState((prevState, props) => ({
//       counter: prevState.count + props.diff
// }));
// State updates are independent. The state object of a component may contain multiple attributes and React allows to use setState() function to update only a subset of those attributes as well as using multiple setState() methods to update each attribute value independently. For example, let us take the following component state into account. 
// this.setState(function(prevState, props){
//     return {counter: prevState.count + props.diff};
// });