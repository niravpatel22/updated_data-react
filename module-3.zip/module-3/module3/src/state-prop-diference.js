// Difference between Props and State
// We have already learned about Props and we got to know that Props are also objects that hold information to control the behavior of that particular component, sounds familiar to State indeed but props and states are nowhere near be same.Let us differentiate the two.

// Props are immutable i.e.once set the props cannot be changed, while State is an observable object that is to be used to hold data that may change over time and to control the behavior after each change.
// States can be used in Class Components, Functional components with the use of React Hooks(useState and other methods) while Props don’t have this limitation.
// While Props are set by the parent component, the State is generally updated by event handlers.For example, let us consider the toggle theme of the GeeksforGeeks { IDE } page.It can be implemented using a State where the probable values of the State can be either light or dark and upon selection, the IDE changes its color.

// Difference between Props and State
// We have already learned about Props and we got to know that Props are also objects that hold information to control the behavior of that particular component, sounds familiar to State indeed but props and states are nowhere near be same. Let us differentiate the two.

// Props are immutable i.e. once set the props cannot be changed, while State is an observable object that is to be used to hold data that may change over time and to control the behavior after each change.
// States can be used in Class Components, Functional components with the use of React Hooks (useState and other methods) while Props don’t have this limitation.
// While Props are set by the parent component, the State is generally updated by event handlers. For example, let us consider the toggle theme of the GeeksforGeeks {IDE} page. It can be implemented using a State where the probable values of the State can be either light or dark and upon selection, the IDE changes its color. from "react";