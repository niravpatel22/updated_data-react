import React from "react";


const CompoFun= function ()
{
    return (
        <h1>
            <ul>
                <li>This is FUNCTION component</li>
            </ul>
        </h1>
    )
}


const CompoCls = class Compo extends React.Component
{
    
    render()
    {
        return(

            <h1>
            <ul>
                <li>This is CLASS component</li>
            </ul>
        </h1>
            
        )
    }
}

 


function ComponentMixed()
{
    return (
        <div>
            <CompoFun/>
            <CompoCls/>
        </div>
    )
}

export default ComponentMixed;
