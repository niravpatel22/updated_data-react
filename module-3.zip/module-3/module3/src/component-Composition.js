import React from "react";


class Header extends React.Component {
    render() {
        return (
            <h1>This is Header....!</h1>
        )
    }
}

class Navbar extends React.Component {
    render() {
        return (
            <h1>This is Navbar....!</h1>
        )
    }
}

function Content()
{
    return (
        <h1>This is Content....!</h1>
    )
}

function Footer()
{
    return (
        <h1>This is Footer....!</h1>
    )
}

class WebPage extends React.Component
{
    render()
    {
        return(
            <>
                <Header/>
                <Navbar/>
                <Content/>
                <Footer/>
            
            </>
        )
    }
}

export default WebPage;