import React from "react";
class Ex1 extends React.Component
{
    render(){
        return(
            <div>
                <h1>This is the example of Default Prop of React..!</h1>
                <h3>Number value : {this.props.num}</h3>
                {/* <h3>Arry value : {this.props.courses}</h3> */}

                <h3>{   
                    this.props.courses.map(function coursesIterator(v,i){

                        return ( 
                            "course "+(i+1)+". " + v + " "
                            
                        )

                    })
                    
                    
                    
                    }</h3>
            </div>
        )
    }
}

Ex1.defaultProps = {
    num :1,
    courses: ["React Js","Angular Js","PHP"]
    
}


export default Ex1;