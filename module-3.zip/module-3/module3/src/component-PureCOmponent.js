import React from "react";

class PureCompo extends React.PureComponent 
{
    render()
    {
        return(
            <h1>This is PURE Component...!</h1>
        )
    }
}

export default PureCompo;