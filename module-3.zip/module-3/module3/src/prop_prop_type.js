import React from "react";
import PropTypes from "prop-types";


class Greet extends React.Component {
    render() {
        return (
            <div>
                <h2>Name : {" " + this.props.name}</h2>
                <h2>Age : {" " + this.props.age}</h2>
                <h2>Course : {" " + this.props.course}</h2>

               
            </div>

        )
    }
}


class PropTypesEx extends React.Component
{
    render()
    {
        return (
            <div>
                <h2>{this.props.numProp}</h2>
                <h2>{this.props.stringProp}</h2>
                <h2>{this.props.booleanProp}</h2>
                <h2>{this.props.arrayProp}</h2>
                <h2>{this.props.objProp}</h2>

            </div>
        )
    }
}

PropTypesEx.propTypes = {
    numProp : PropTypes.number,
    stringProp : PropTypes.string,
    booleanProp : PropTypes.bool,
    arrayProp : PropTypes.array
}

PropTypesEx.defaultProps = {
    numProp :   23,
    stringProp : "StrName",
    booleanProp : true,
    arrayProp : [12,34,"hi",9879,"Sdfsdf"]
}

function PropEx() {
    return (
        <div>
            <Greet name="React" age="Unknown" course="AI"/>
        <PropTypesEx/>

        
        </div>
    )
}

export default PropEx;