import React from "react";


class Parent extends React.Component
{
    render(){

        return(

            
           <div>
                <h2>This is Parent</h2>
                <ul>
                    <li><Child name="Child1" action ="Eating"/></li>
                    <li><Child name="Child2" action ="Playing"/></li>
                    <li><Child name="Child3" action ="Crying"/></li>
                    <li><Child name="Child4" action ="Drawing"/></li>
                    <li><Child name="Child5" action ="Watching TV"/></li>
                </ul>
           </div>
        )
    }
}

class Child extends React.Component 
{
    render()
    {
        return(
            <div>
                  <h1>Hello {this.props.name}</h1>
            <h2>This is Child Component</h2>
            <h2>And you are {this.props.action}...!!!</h2>
            </div>
        )
    }

}

export default Parent;