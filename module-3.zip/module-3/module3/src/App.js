
import WebPage from "./component-Composition";
import PureCompo from "./component-PureCOmponent";
import ComponentMixed from "./components";
import Test from "./components-life-cycle";
import Parent from "./passing-accessing-props";
import Ex1 from "./passing-accessing-props-default-props";
import PropEx from "./prop_prop_type";

const JSX_ = function testJSX()
{
  
  let i=1;
  const ele = <h1 className="x">This is sample JSX <br/> {(i==1)? "THIS IS JSX AGAIN wid condition...!" : "!!!"  }</h1>;

  const ele1 = <ul>
                <li>{ele}</li>
                <li>{ele}</li>
                <li>{ele}</li>
              </ul>
          const element =
           <div>
            <h1 className="hello">Hello Geek</h1>
          {/* <h2 data-sampleAttribute="sample">Custom attribute</h2> */}
          </div>
          
          
          
          

          return (
            <u>{ele1} {element}</u>
          )
}

function App() {
  return (

    // testJSX()
      <div>

        <JSX_/>
      <ComponentMixed/>
      <PureCompo/>
     <Test/>
      <PropEx/>
      <Parent/>
      <Ex1/>
      <WebPage/>
      
        
      </div>
  );
}

export default App;
