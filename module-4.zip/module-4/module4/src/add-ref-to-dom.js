import * as React from "react";
import ReactDOM from "react-dom";

 function AppRefCurrent() {
 const ref = React.useRef();

 function focus() {
   ref.current.focus();
 }

 return (
   <div className="App">
     <input ref={ref} placeholder="my input" />
     <button onClick={focus}>Focus</button>
   </div>
 );
}

export default AppRefCurrent;



