import userEvent from "@testing-library/user-event";
import React, { useState } from "react";

function Ex1() {
    // const [brand,setBrand] = useState("Skybags");

    // return(<>

    //     <h1>My bag is of brand name {brand}</h1>

    //     <button onClick={()=>{setBrand("Nike")}}>Nike</button>

    // </>)


    // ===================================

    // const [shoeSize,setShoeSize] = useState("9");
    // const [shoeColor,setShoeColor] = useState("White");
    // const [shoeBrand,setShoeBrand] = useState("Lee Cooper");
    // const [shoePrice,setShoePrice] = useState("Rs. 4680");

    // return(<>

    //     <h1>
    //         My shoeBrand is {shoeBrand}..!
    //         <p>
    //         and is in color {shoeColor} having size {shoeSize} </p>
    //         <p>and of price {shoePrice}..!!!</p>
    //     </h1>

    //     <button onClick={()=>{setShoeBrand("Red Tape")}}>Change Shoe</button>
    //     <button onClick={()=>{setShoeColor("Red")}}>Change Shoe</button>


    // </>)

    // ==============================================================

    // const [shoe,setShoe] = useState(
    //     {
    //         shoeSize : "9",
    //         shoeBrand : "Adidas",
    //         shoeColor : "white",
    //         shoePrice : 5000

    //     }
    // );


    // return(<>

    //     <h1>
    //         My shoeBrand is {shoe.shoeBrand}..!
    //         <p>
    //         and is in color {shoe.shoeColor} having size {shoe.shoeSize} </p>
    //         <p>and of price {shoe.shoePrice}..!!!</p>
    //     </h1>




    // </>)



    // ==========================================================


    const [shoe,setShoe] = useState({

        brand:'Nike',
        color: "Red",
        price: 5000
    })

    const updateColor = ()=>{
        setShoe((prevState)=>{

            return { ...prevState, color:"Pink"}

        })
    }

    const updateBrand = ()=>{
        setShoe((prevState)=>{

            return { ...prevState, brand:"ADIDAS"}

        })
    }

    const updatePrice = ()=>{
        setShoe((prevState)=>{

            return { ...prevState, price:"Rs. 4300"}

        })
    }

    return(<>
    
        <h1>Shoe Details</h1>

        <p>Brand: {shoe.brand}</p>
        <p>Color: {shoe.color}</p>
        <p>Price: {shoe.price}</p>

        <button onClick={updateColor}>Update Color</button>
        <button onClick={updateBrand}>Update Brand</button>
        <button onClick={updatePrice}>Update Price</button>
    
    
    </>)

}


  

export default Ex1;