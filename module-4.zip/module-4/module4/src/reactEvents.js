import { type } from "@testing-library/user-event/dist/type";
import React from "react";

function TestEvent()
{

    const clickEvent = (x,y)=>{

        alert("HEllo Click..!");
     
    }


    const clickEvent1 = (x,y)=>{

        
        x = x+y;
        document.getElementById('res').innerHTML =  x;
    }

    const EventObject = (e)=>{

        document.getElementById('res').innerHTML = e.type;
        // document.getElementById('res').innerHTML = me.type;
        // document.getElementById('res').innerHTML = dc.type;
        // document.getElementById('res').innerHTML = ml.type;

    }

    return(<>

        <h1 id="res"></h1>
        <button onClick={clickEvent}>Click</button>
        <button onClick={()=>clickEvent1(12,34)}>Click SUM</button>
        <button onClick={(e1)=>{EventObject(e1)}}>Click EVENT</button>
        <button onMouseEnter={(e1)=>{EventObject(e1)}}>Mouse Enter EVENT</button>
        <button onDoubleClick={(e1)=>{EventObject(e1)}}>Double Click EVENT</button>
        <button onMouseLeave={(e1)=>{EventObject(e1)}}>Mouse Leave EVENT</button>
       
        
    
        
    
    </>)
    

}


export default TestEvent;