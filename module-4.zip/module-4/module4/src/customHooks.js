// We will use the JSONPlaceholder service to fetch fake data. This service is great for testing applications when there is no existing data.

// To learn more, check out the JavaScript Fetch API section.

// Use the JSONPlaceholder service to fetch fake "todo" items and display the titles on the page:import { useState, useEffect } from "react";


import { useState,useEffect } from "react";
import React from "react";
const useFetch = (url) => {
    const [data, setData] = useState(null);
  
    useEffect(() => {
      fetch(url)
        .then((res) => res.json())
        .then((data) => setData(data));
    }, [url]);
  
    return [data];
  };
  
  export default useFetch;