import { useState, useEffect } from "react";
import React from "react";




function Change_course() {
  const [course, setCourse] = useState("WD");
  const [duration, setDuration] = useState(3);

  useEffect(() => {
    setDuration(() => duration + 2);
  }, [course]); // <- add the course variable here

  return (
    <>
      <p>Course: {course}</p>
      <button onClick={() => setCourse("React")}>Change Course and Duration</button>
      <p>Duration: {duration}</p>
      <Timer/>
    </>
  );
}



function Timer() {
    const [count, setCount] = useState(0);
  
    useEffect(() => {
      let timer = setTimeout(() => {
      setCount((count) => count + 1);
    }, 1000);
  
    return () => clearTimeout(timer)
    }, []);
  
    return <h1>I've rendered {count} times!</h1>;
  }
  
export default Change_course;