import React  from "react";
import { ReactDOM } from "react";

function ListComponent(props) {
    const listItems = myList.map((item) =>
    <li>{item}</li>
    ); 
    return (
    <ul>{listItems}</ul>
    );
}

const myList = ["Lotus", "Rose", "Sunflower", "Marigold", "Lily"];
ReactDOM.render(
    <ListComponent myList={myList} />, 
    document.getElementById('root')
);
