import React from "react";
function Students(props) {
    return <li>I am  { props.names }</li>;
  }
  
  function Details() {
    const info = [
      {id: 1, nm: 'Krishiv'},
      {id: 2, nm: 'Dhawni'},
      {id: 3, nm: 'Dhairya'}
    ];
    return (
      <>
        <h1>List of students are:</h1>
        <ul>
          {info.map((i) => <Students key={i.id} names={i.nm} />)}
        </ul>
      </>
    );
  }

  export default Details;