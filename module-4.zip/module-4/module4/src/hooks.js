import React, { useState } from "react";

function ChangeNames()
{

    const [name,setName] = useState("Nirav");

    return(<>

        <h1>THIS IS HOW STATE WORKS...! {name}</h1>
        <button onClick={()=>setName("Krishiv")}>Krishiv</button>
        <button onClick={()=>setName("Priti")}>Priti</button>
        <button onClick={()=>setName("Dhwani")}>Dhwani</button>
        <button onClick={()=>setName("Dhairya")}>Dhairya</button>
        
    
    </>)

}

export default ChangeNames;