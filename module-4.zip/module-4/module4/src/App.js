// import logo from './logo.svg';
// import './App.css';

import React from "react";

import ChangeNames from "./hooks";
import Details from "./list";
import TestEvent from "./reactEvents";
import Component1 from "./useContext";
import Compo1 from "./useContextSolution";
import Ex2 from "./useEffect";
import Change_course from "./useEffect2-dependencies";
import TestRef from "./useRef";
import Ex1 from "./usestate1";
import ExMemo from "./useMemo-Callback";
import Home from "./fectCustomhookdata";

import AppRefEx from "./React-ref";
import AppFromValidate from "./React-ref-FormValidation";

import AppListKeyMap from "./list-keys";
import AppRefCurrent from "./add-ref-to-dom";
import AppPlayVideo from "./ref-video-play";
import CustomTextInput from "./conditional-ref";
import Forward_ref from "./forwarding-ref";





function App() {
  return (
    <div>
        <Details/>
        <TestEvent/>
        <ChangeNames/>
        <Ex1/>
        <Ex2/>
        <Change_course/>
        <Component1/>
        <Compo1/>
        <TestRef/>
        <ExMemo/>
        <Home/>
        <AppRefEx/>
        <AppFromValidate/>
        
       <AppListKeyMap/>
       <AppRefCurrent/>
       <AppPlayVideo/>
       <CustomTextInput/>
       <Forward_ref/>

      

       
        
    </div>
  );
}

export default App;
