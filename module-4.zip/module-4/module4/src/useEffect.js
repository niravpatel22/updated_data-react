// The useEffect Hook allows you to perform side effects in your components.

// Some examples of side effects are: fetching data, directly updating the DOM, and timers.

// useEffect accepts two arguments. The second argument is optional.

// useEffect(<function>, <dependency>)




import { useEffect, useState } from "react";
import React from "react";

function Ex2() {
    const [users, countUsers] = useState(0);
    
    // useEffect(()=>{

    //     setTimeout(()=>{
    //         countUsers((users)=>users+1)
    //     },1000)
    // })


    ///setTimeout should work and stop but it didnt

    useEffect(()=>{

        setTimeout(()=>{
            countUsers(users => users+1)
        },1000)
    },[])

    return(<>

        <h1>
            {users}
        </h1>
    
    </>)


}



export default Ex2;
