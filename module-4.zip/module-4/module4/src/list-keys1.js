import React from 'react'

// making some temporary blog data, which has unique id, title, and text
const posts = [
  { id: 1, title: 'Hello World', text: 'lists in react!' },
  { id: 2, title: 'Hello World', text: 'keys in react!' },
]

// Blog function to create a list
function Blog(props) {
  const list component = (
    <ul>
      // function to map through posts and display the post title
      {props. posts.map((post) => (
        <li key={post.id}>{post.title}</li>
      ))}
    </ul>
  )

  // function to map through post and display post title and post text
  const printComponent = props. posts.map((post) => (
    <div key={post.id}>
      <h3>{post.title}</h3>
      <p>{post.text}</p>
    </div>
  ))

  return (
    <div>
      {listComponent}
      <hr />
      {printComponent}
    </div>
  )
}

const root = ReactDOM.createRoot(document.getElementById('root'))
root.render(<Blog posts={posts} />)
